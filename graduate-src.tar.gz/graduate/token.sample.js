/**
 * Graduation Letter - External Configuration Plate
 *
 * Usage: Place this file in the same directory as index.html.
 * When index.html is accessed with ?t=<filename>, it loads <filename>.js
 *
 * New format: paragraphs are plain strings, photos & caption supported.
 */

window.LETTER_DATA = {
  // Optional token verification (null or remove to disable)
  token: "2026",

  // Main Content
  greeting: "Dear Class of 2026,",

  paragraphs: [
    "那个迟到被抓的早晨、一起溜去小卖部的课间、还有那摞写满笔记再也不想翻开的课本——高中这三年，我们就这样跌跌撞撞地走了过来。",
    "或许我还没学会怎么好好告别，但我知道，每一段旅程的终点，都是下一程的起点。所以，这次用"明天见"代替"再见"吧。",
    "愿你在六月的考场上落笔生花，愿你的远方明亮而宽广。"
  ],

  closing: "From [Your Name]",
  date: "June 2026",

  // Photos (1-3 URLs, will be displayed as scattered prints)
  photos: [
    // "https://example.com/photo1.jpg",
    // "https://example.com/photo2.jpg",
  ],

  // Caption on first photo (handwritten style)
  caption: "Summer 2023",

  // Fine-tuning options
  options: {
    developDelay: 1.2  // Seconds between each line developing
  }
};
