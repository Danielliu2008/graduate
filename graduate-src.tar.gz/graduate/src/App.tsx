import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Stars from './components/Stars';
import Envelope from './components/Envelope';
import Letter from './components/Letter';
import Photo from './components/Photo';
import { initPlayer, startBGM } from './services/player';
import { LETTER_TOKENS } from './tokens';
import type { LetterConfig } from './tokens';

export default function App() {
  const [stage, setStage] = useState<'idle' | 'opening' | 'reading'>('idle');
  const [dataReady, setDataReady] = useState(false);
  const [config, setConfig] = useState<LetterConfig>(LETTER_TOKENS);

  useEffect(() => {
    initPlayer();

    const checkData = () => {
      const globalData = (window as any).LETTER_DATA;
      if (globalData) {
        setConfig(globalData);
        setDataReady(true);
        return true;
      }
      return false;
    };

    if (!checkData()) {
      const interval = setInterval(() => {
        if (checkData()) clearInterval(interval);
      }, 50);

      const timeout = setTimeout(() => {
        clearInterval(interval);
      }, 10000);

      return () => {
        clearInterval(interval);
        clearTimeout(timeout);
      };
    }
  }, []);

  const handleOpen = () => {
    if (stage !== 'idle') return;

    // Request fullscreen in user gesture callback (browser requirement)
    try {
      document.documentElement.requestFullscreen();
    } catch (e) { /* fullscreen not supported, continue anyway */ }

    startBGM();
    setStage('opening');

    // Flap: 1.2s delay + 1s duration = 2.2s, then wait for settle
    // Transition to reading at ~3.5s
    setTimeout(() => {
      setStage('reading');
    }, 3500);
  };

  // Loading state
  if (!dataReady && !LETTER_TOKENS.greeting) {
    return (
      <main className="min-h-screen bg-night flex items-center justify-center">
        <Stars />
        <div className="text-gold font-serif animate-pulse tracking-widest text-sm uppercase opacity-50">
          Loading Letter...
        </div>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen bg-night selection:bg-gold/30" style={{ overflow: 'hidden' }}>
      {/* Background layers */}
      <div className="desk-surface" />
      <Stars />
      <div className="vignette-overlay" />

      {/* ── Envelope: idle & opening → centered ── */}
      <AnimatePresence>
        {(stage === 'idle' || stage === 'opening') && (
          <motion.div
            key="envelope-main"
            className="absolute inset-0 flex items-center justify-center z-10"
            exit={{
              scale: 0.25,
              opacity: 0,
              filter: 'blur(3px)',
            }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          >
            <Envelope onOpen={handleOpen} isOpened={stage === 'opening'} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Reading state: fullscreen container ── */}
      <AnimatePresence>
        {stage === 'reading' && (
          <motion.div
            key="reading-content"
            className="absolute inset-0 z-20"
            style={{ overflow: 'visible' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            {/* Wrapper: plain div for centering (motion would override transform) */}
            <div style={{
              position: 'absolute',
              top: '50px',
              left: '50%',
              transform: 'translateX(-50%)',
              width: 'calc(100vw - 40px)',
            }}>
              <motion.div
                initial={{ opacity: 0, y: 60 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              >
                {/* Letter — relative inside wrapper, rotate 1.5deg */}
                <div style={{ position: 'relative', transform: 'rotate(1.5deg)' }}>
                  <Letter config={config} />
                </div>

                {/* Photo — absolute inside wrapper, overlaps letter top-left */}
                {config.photos && config.photos.length > 0 && (
                  <motion.div
                    className="absolute pointer-events-none"
                    style={{ top: '-20px', left: '-15px', zIndex: 10 }}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5, duration: 1, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <Photo photos={config.photos} caption={config.caption} />
                  </motion.div>
                )}
              </motion.div>
            </div>

            {/* Envelope — decorative, bottom-left */}
            <motion.div
              className="absolute z-10 pointer-events-none"
              style={{ bottom: '40px', left: '24px' }}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 0.7, scale: 1 }}
              transition={{ delay: 1, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            >
              <Envelope isOpened={true} onOpen={() => {}} isMini />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
