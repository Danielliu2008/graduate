import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface EnvelopeProps {
  onOpen: () => void;
  isOpened: boolean;
  isMini?: boolean;
}

const Envelope: React.FC<EnvelopeProps> = ({ onOpen, isOpened, isMini }) => {
  const [flapZ, setFlapZ] = React.useState(40);

  React.useEffect(() => {
    if (isOpened) {
      const timer = setTimeout(() => setFlapZ(10), 2200);
      return () => clearTimeout(timer);
    } else {
      setFlapZ(40);
    }
  }, [isOpened]);

  // ── Mini decorative envelope ──
  if (isMini) {
    return (
      <div
        className="relative select-none"
        style={{ width: '80px', height: '56px' }}
      >
        {/* Airmail stripe frame */}
        <div className="absolute inset-0 rounded-sm overflow-hidden airmail-stripe-bg">
          {/* Inner cream body */}
          <div
            style={{
              position: 'absolute',
              inset: '4px',
              background: 'var(--color-envelope)',
            }}
          >
            {/* Mini AIR MAIL text */}
            <div style={{ padding: '4px 0 0 6px' }}>
              <span style={{ fontSize: '5px', fontWeight: 700, color: 'var(--color-airmail-blue)', letterSpacing: '0.15em', opacity: 0.6 }}>
                AIR MAIL
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Main envelope (idle & opening) ──
  return (
    <div
      className="relative cursor-pointer group select-none"
      style={{
        perspective: '1000px',
        width: '85vw',
        maxWidth: '26rem',
        aspectRatio: '4/3',
      }}
      onClick={onOpen}
    >
      {/* Drop shadow */}
      <div className="absolute inset-0 bg-black/40 blur-2xl translate-y-4 scale-95 rounded-md" />

      {/* Airmail frame: stripe bg + inner cream body with margin */}
      <div className="absolute inset-0 rounded-sm overflow-hidden airmail-stripe-bg">
        <div
          className="relative w-full h-full overflow-visible"
          style={{ margin: '10px', background: 'var(--color-envelope)' }}
        >
          {/* Spacer: content starts below flap area (20% + gap) */}
          <div style={{ height: 'calc(20% + 6px)' }} />

          {/* Content */}
          <div className="px-5">
            {/* AIR MAIL + PAR AVION */}
            <div className="flex items-center justify-between mb-3">
              <span className="airmail-label" style={{ fontSize: '10px' }}>AIR MAIL</span>
              <span className="airmail-label" style={{ opacity: 0.4, fontSize: '8px' }}>PAR AVION</span>
            </div>

            {/* Address lines */}
            <div className="space-y-2">
              <div className="w-full h-px bg-secondary-text/20" />
              <div className="w-3/4 h-px bg-secondary-text/15" />
              <div className="w-5/6 h-px bg-secondary-text/10" />
            </div>
          </div>

          {/* Stamp */}
          <div
            className="absolute w-9 h-11 border-2 border-airmail-red/20 rounded-sm flex items-center justify-center bg-white/50"
            style={{ top: 'calc(20% + 14px)', right: '16px' }}
          >
            <span className="text-airmail-red/25 text-base">✉</span>
          </div>
        </div>
      </div>

      {/* Flap — 20% height */}
      <motion.div
        className="absolute top-0 left-0 w-full origin-top"
        style={{
          height: '20%',
          transformStyle: 'preserve-3d',
          backfaceVisibility: 'visible',
          zIndex: flapZ,
        }}
        initial={{ rotateX: 0 }}
        animate={isOpened ? { rotateX: -180 } : { rotateX: 0 }}
        transition={{ delay: 1.2, duration: 1, ease: 'easeInOut' }}
      >
        <svg className="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M 0 0 L 100 0 L 50 100 L 0 0 Z" fill="#ede8df" stroke="var(--color-gold)" strokeWidth="0.2" strokeOpacity="0.2" />
          <line x1="10" y1="0" x2="50" y2="90" stroke="var(--color-gold)" strokeWidth="0.1" strokeOpacity="0.1" />
          <line x1="90" y1="0" x2="50" y2="90" stroke="var(--color-gold)" strokeWidth="0.1" strokeOpacity="0.1" />
        </svg>
      </motion.div>

      {/* Tap instruction */}
      <AnimatePresence>
        {!isOpened && (
          <motion.div
            className="absolute -bottom-14 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <p className="text-gold/50 text-[10px] tracking-[0.4em] font-serif uppercase">Tap to Open</p>
            <motion.div
              className="w-px h-8 bg-gradient-to-b from-gold/50 to-transparent"
              animate={{ scaleY: [0, 1, 0], opacity: [0, 1, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Envelope;
