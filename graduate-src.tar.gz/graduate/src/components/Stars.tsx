import React, { useEffect, useRef } from 'react';
import { CONFIG } from '../config';

const Stars: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Dust[] = [];

    class Dust {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      baseOpacity: number;
      phase: number;

      constructor() {
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.size = Math.random() * 1.5 + 0.5;  // 0.5 – 2px
        this.speedX = (Math.random() - 0.5) * 0.1;
        this.speedY = (Math.random() - 0.5) * 0.05 - 0.02;
        this.baseOpacity = Math.random() * 0.2 + 0.3;  // 0.3 – 0.5
        this.opacity = this.baseOpacity;
        this.phase = Math.random() * Math.PI * 2;
      }

      update(time: number) {
        // Gentle sine-wave drift
        this.x += this.speedX + Math.sin(time * 0.001 + this.phase) * 0.04;
        this.y += this.speedY;

        // Subtle opacity oscillation
        this.opacity = this.baseOpacity + Math.sin(time * 0.0005 + this.phase) * 0.08;

        // Wrap around edges
        if (this.y < -10) this.y = canvas!.height + 10;
        if (this.y > canvas!.height + 10) this.y = -10;
        if (this.x < -10) this.x = canvas!.width + 10;
        if (this.x > canvas!.width + 10) this.x = -10;
      }

      draw() {
        if (!ctx) return;
        ctx.fillStyle = CONFIG.COLORS.dust;
        ctx.globalAlpha = Math.max(0, Math.min(1, this.opacity));
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = Array.from({ length: 35 }, () => new Dust());
    };

    let startTime: number;
    const animate = (time: number) => {
      if (!startTime) startTime = time;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.update(time - startTime);
        p.draw();
      });
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animationFrameId = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return <canvas ref={canvasRef} className="stars-container" />;
};

export default Stars;
