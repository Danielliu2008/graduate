import React, { useState } from 'react';
import { motion } from 'motion/react';

interface PhotoProps {
  photos: string[];
  caption?: string;
}

const PlaceholderBlock = ({ color }: { color: string }) => (
  <div className="w-full h-full flex flex-col items-center justify-center gap-1" style={{ backgroundColor: color }}>
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" opacity="0.3">
      <rect x="3" y="3" width="18" height="18" rx="2" stroke="#4a3f35" strokeWidth="1.5"/>
      <circle cx="8.5" cy="8.5" r="2" stroke="#4a3f35" strokeWidth="1.2"/>
      <path d="M3 16l5-5 3 3 4-4 6 6" stroke="#4a3f35" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
    <span style={{ fontSize: '9px', fontFamily: 'var(--font-serif)', color: '#4a3f35', opacity: 0.35 }}>3:4</span>
  </div>
);

const Photo: React.FC<PhotoProps> = ({ photos, caption }) => {
  if (!photos || photos.length === 0) return null;

  const src = photos[0];
  const hasImage = src && src.length > 0;
  const [imgError, setImgError] = useState(false);

  return (
    <motion.div
      className="pointer-events-none"
      style={{
        width: '120px',
        height: '160px',
      }}
      initial={{ opacity: 0, y: -20, scale: 0.9, rotate: -5 }}
      animate={{ opacity: 1, y: 0, scale: 1, rotate: -5 }}
      transition={{ delay: 0, duration: 1, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Polaroid frame: white bg, 8px side padding, 20px bottom padding */}
      <div
        style={{
          width: '100%',
          height: '100%',
          backgroundColor: '#fff',
          boxShadow: '0 2px 12px rgba(0,0,0,0.2), 0 1px 3px rgba(0,0,0,0.1)',
          padding: '8px 8px 20px 8px',
          boxSizing: 'border-box',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Photo area: 3:4 ratio */}
        <div style={{ flex: 1, overflow: 'hidden', borderRadius: '1px' }}>
          {hasImage && !imgError ? (
            <img
              src={src}
              alt=""
              style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'sepia(0.15) contrast(0.95)' }}
              loading="lazy"
              onError={() => setImgError(true)}
            />
          ) : (
            <PlaceholderBlock color="#c4b5a0" />
          )}
        </div>

        {/* Caption in bottom white edge */}
        {caption && (
          <div
            style={{
              position: 'absolute',
              bottom: '4px',
              left: '10px',
              right: '6px',
              fontFamily: 'var(--font-handwrite)',
              fontSize: '10px',
              color: 'rgba(139,125,107,0.6)',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {caption}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default Photo;
