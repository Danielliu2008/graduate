import React from 'react';
import { motion } from 'motion/react';
import { LetterConfig } from '../tokens';
import MusicButton from './MusicButton';

interface LetterProps {
  config: LetterConfig;
}

const Letter: React.FC<LetterProps> = ({ config }) => {
  const { greeting, paragraphs, closing, date, options } = config;
  const developDelay = options?.developDelay ?? 1.2;

  return (
    <div
      className="relative w-full paper-texture"
      style={{
        backgroundColor: 'var(--color-paper)',
        borderRadius: '8px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.25), 0 1px 3px rgba(0,0,0,0.15)',
        padding: '24px',
        fontSize: '16px',
        lineHeight: '1.8',
        color: 'var(--color-text)',
        fontFamily: 'var(--font-serif)',
      }}
    >
      {/* Music Player */}
      <div className="absolute top-3 right-3 z-10">
        <MusicButton delay={2} />
      </div>

      {/* Content */}
      <div className="space-y-4">
        {/* Greeting — develops first */}
        <motion.h1
          style={{ fontSize: '18px', fontWeight: 600, color: 'var(--color-accent)', letterSpacing: '0.05em' }}
          initial={{ opacity: 0, filter: 'blur(4px)' }}
          animate={{ opacity: 1, filter: 'blur(0px)' }}
          transition={{ delay: 0.8, duration: 1.5, ease: 'easeOut' }}
        >
          {greeting}
        </motion.h1>

        {/* Paragraphs — develop one by one */}
        {paragraphs.map((para, idx) => (
          <motion.p
            key={idx}
            style={{ fontSize: '16px', lineHeight: '1.8', margin: 0 }}
            initial={{ opacity: 0, filter: 'blur(4px)' }}
            animate={{ opacity: 1, filter: 'blur(0px)' }}
            transition={{
              delay: 0.8 + (idx + 1) * developDelay,
              duration: 1.5,
              ease: 'easeOut',
            }}
          >
            {para.content}
          </motion.p>
        ))}

        {/* Closing & Date — develops last */}
        <motion.div
          style={{ paddingTop: '16px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px' }}
          initial={{ opacity: 0, filter: 'blur(3px)' }}
          animate={{ opacity: 1, filter: 'blur(0px)' }}
          transition={{
            delay: 0.8 + (paragraphs.length + 1) * developDelay,
            duration: 1.5,
            ease: 'easeOut',
          }}
        >
          <span style={{ fontStyle: 'italic', color: 'var(--color-secondary-text)' }}>
            {closing}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ height: '1px', width: '40px', background: 'rgba(212,175,55,0.3)' }} />
            <span style={{ fontSize: '10px', letterSpacing: '0.3em', color: 'rgba(212,175,55,0.7)', textTransform: 'uppercase' }}>
              {date}
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Letter;
