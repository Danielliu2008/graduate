/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Paragraph {
  content: string;
}

export interface LetterConfig {
  token?: string;
  greeting: string;
  paragraphs: Paragraph[];
  closing: string;
  date: string;
  photos?: string[];
  caption?: string;
  options?: {
    developDelay?: number;
  };
}

// Default fallback data if window.LETTER_DATA is not found
const DEFAULT_DATA: LetterConfig = {
  greeting: 'Dear Class of 2026,',
  paragraphs: [
    { content: '那个迟到被抓的早晨、一起溜去小卖部的课间、还有那摞写满笔记再也不想翻开的课本——高中这三年，我们就这样跌跌撞撞地走了过来。' },
    { content: '或许我还没学会怎么好好告别，但我知道，每一段旅程的终点，都是下一程的起点。所以，这次用"明天见"代替"再见"吧。' },
    { content: '愿你在六月的考场上落笔生花，愿你的远方明亮而宽广。' },
  ],
  closing: 'From [署名]',
  date: 'June 2026',
  photos: ['', '', ''],
  caption: 'Summer 2023',
  options: {
    developDelay: 1.2,
  }
};

// Access window in a way that doesn't break SSR (though this is SPA)
const globalData = typeof window !== 'undefined' ? (window as any).LETTER_DATA : null;

// Merge global data with defaults, handling both old (showIcon) and new formats
function normalizeConfig(data: any): LetterConfig {
  if (!data) return DEFAULT_DATA;
  return {
    ...DEFAULT_DATA,
    ...data,
    paragraphs: (data.paragraphs || DEFAULT_DATA.paragraphs).map((p: any) =>
      typeof p === 'string' ? { content: p } : { content: p.content }
    ),
    photos: data.photos || [],
    caption: data.caption || '',
  };
}

export const LETTER_TOKENS: LetterConfig = normalizeConfig(globalData);
